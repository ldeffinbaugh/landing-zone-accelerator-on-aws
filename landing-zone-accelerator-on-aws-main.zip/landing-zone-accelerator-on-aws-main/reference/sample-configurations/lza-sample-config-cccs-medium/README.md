# Canadian Centre for Cyber Security (CCCS) Cloud Medium (CCCS Medium)

This sample configuration has been migrated to the GitHub repository below: <br>

[Landing Zone Accelerator on AWS for Canadian Centre for Cyber Security (CCCS) Cloud Medium](https://github.com/aws-samples/landing-zone-accelerator-on-aws-for-cccs-medium)
