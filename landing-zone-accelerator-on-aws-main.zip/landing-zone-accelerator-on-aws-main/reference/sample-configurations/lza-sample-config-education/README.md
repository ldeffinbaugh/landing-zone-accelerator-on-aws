# Landing Zone Accelerator on AWS for Education

This sample configuration has been migrated to the GitHub repository below: <br>

[Landing Zone Accelerator on AWS for Education](https://github.com/aws-samples/landing-zone-accelerator-on-aws-for-education)