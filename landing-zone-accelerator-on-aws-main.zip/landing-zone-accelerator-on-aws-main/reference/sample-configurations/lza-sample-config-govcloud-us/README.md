# Landing Zone Accelerator on AWS for United States (US) Federal and Department of Defense (DoD)

The documentation for the GovCloud (US) sample configuration has been moved to the [GovCloud (US) Configuration](https://awslabs.github.io/landing-zone-accelerator-on-aws/latest/sample-configurations/govcloud-us) section of our [GitHub Pages website](https://awslabs.github.io/landing-zone-accelerator-on-aws).
